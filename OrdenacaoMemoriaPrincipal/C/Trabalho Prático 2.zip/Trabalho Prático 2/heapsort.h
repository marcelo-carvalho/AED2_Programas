#ifndef HEAPSORT_H
#define HEAPSORT_H
//=============================================================================
#include "geracao.h"
//=============================================================================
void constroi(int *array, int tamHeap, int* comparacao, int*trocas);
//=============================================================================
int getMaiorFilho(int *array, int i, int tamHeap,int*comparacao);
//=============================================================================
void reconstroi(int *array, int tamHeap, int *comparacao, int *trocas);
//=============================================================================
void heapsort(int *array, int n);
//=============================================================================
#endif