#include "mergesort.h"
#include <stdlib.h>
#include<stdio.h>

//=============================================================================
void mergesort(int *array, int n) {
   int *comparacao; 
   int *trocas;

   *comparacao = 0;
   *trocas = 0;
   mergesortRec(array, 0, n-1,comparacao,trocas);

   printf("\t%d", *comparacao);
   printf("\t%d", *trocas);
}
//=============================================================================
void mergesortRec(int *array, int esq, int dir, int *comparacao, int *trocas){
   if (esq < dir){
      int meio = (esq + dir) / 2;
      mergesortRec(array, esq, meio,comparacao,trocas);
      mergesortRec(array, meio + 1, dir,comparacao,trocas);
      intercalar(array, esq, meio, dir,comparacao,trocas);
   }
}
//=============================================================================
void intercalar(int* array, int esq, int meio, int dir,int *comparacao, int *trocas){
   int n1, n2, i, j, k;

   //Definir tamanho dos dois subarrays
   n1 = meio-esq+1;
   n2 = dir - meio;

   int* a1 = (int*) malloc((n1+1) * sizeof(int)); 
   int* a2 = (int*) malloc((n2+1) * sizeof(int));

   //Inicializar primeiro subarray
   for(i = 0; i < n1; i++){
      a1[i] = array[esq+i];
   }

   //Inicializar segundo subarray
   for(j = 0; j < n2; j++){
      a2[j] = array[meio+j+1];
   }

   //Sentinela no final dos dois arrays
   a1[i] = a2[j] = 0x7FFFFFFF;

   //Intercalacao propriamente dita
   for(i = j = 0, k = esq; k <= dir; k++){
      *comparacao++;
      if(a1[i] <= a2[j]){
         array[k] = a1[i++];
         trocas++;
      }
      else{
          array[k] = a2[i++];
          trocas++;
      }
      //array[k] = (a1[i] <= a2[j]) ? a1[i++] : a2[j++];
   }
}
//=============================================================================